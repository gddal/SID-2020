package readings;

import java.util.Date;

public abstract class Reading {
	
	private String id;
	private Date datime;
	
	
	public Reading(String id, Date datime) {
		this.id=id;
		this.datime=datime;
		
	}


	public String getId() {
		return id;
	}


	public Date getDatime() {
		return datime;
	}


	@Override
	public String toString() {
		return "Reading [id=" + id + ", datime=" + datime + "]";
	}

}
