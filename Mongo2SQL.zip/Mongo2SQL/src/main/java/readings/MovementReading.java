package readings;

import java.util.Date;

public class MovementReading extends Reading {
	

	private int movement;

	
	public MovementReading(String id, Date datime, int movement) {
		super(id,datime);
		this.movement=movement;

		
	}


	public int getMovement() {
		return movement;
	}

	
	
	
}
