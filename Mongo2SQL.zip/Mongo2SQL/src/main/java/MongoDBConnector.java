import java.time.Instant;
import java.util.ArrayList;
import java.util.Date;

import org.bson.Document;

import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import com.mongodb.MongoClient;
import com.mongodb.MongoClientURI;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Filters;
import com.mongodb.operation.OrderBy;

import readings.HumidityReading;
import readings.LuminosityReading;
import readings.MovementReading;
import readings.Reading;
import readings.TemperatureReading;
import utils.G23Utils;

public class MongoDBConnector {
	private MongoClient mongoClient;
	private DB mdb;
	private SettingsLoader settings;

	public MongoDBConnector(String URI, String DBName) {
		mongoClient = new MongoClient( new MongoClientURI(URI)); 
		mdb = mongoClient.getDB(DBName);



	}

	public void mongotoArrayList(){
		String[] stringsarray = SettingsLoader.getdbStrings();	

		for(int i = 0; i < stringsarray.length; i++) {
			String[] stringinfo = stringsarray[i].split("#");

			String collection = stringinfo[0];
			String sensorfieldname = stringinfo[1];
			String sensortype = stringinfo[2];

			DBCollection table = mdb.getCollection(collection);
			DBCursor cursor = table.find().sort(new BasicDBObject(SettingsLoader.getMongoDateTimeField(),-1)); //SORT DATES
			
			int	currentlyread = 0;

			System.out.println(SettingsLoader.getNumberReads()[0]);
			while(cursor.hasNext() && (currentlyread < SettingsLoader.getNumberReads()[i] || SettingsLoader.getNumberReads()[i] == -1)) { //Checks if there's something to be read and if it has already read all allowed entries. Note that if it's -1 it's set to infinite.

				DBObject dbo = cursor.next();
				
				//exclude erroneous dates
				Date readdate = (Date)dbo.get(SettingsLoader.getMongoDateTimeField()); //Date includes time (hour min sec)
				Date currentdate = new Date();
				if(readdate.compareTo(currentdate) <= 0) { // if 1st date occurs before or at the same time as 2nd date
					mongoObjecttoReadingLists(dbo,sensorfieldname,sensortype);
					currentlyread++;
					SettingsLoader.setewmaInitialValue();
				}
				else
					System.out.println("Read date " + readdate + " will be ignored as is after " + currentdate);


			}

		}


	}
	

	public void mongoObjecttoReadingLists(DBObject dbo, String sensorfieldname, String sensortype) { //TODO possibly change or remove sensortype
		//TODO move [x] to something more readable like wtf
		String tstring = SettingsLoader.getdbStrings()[0].split("#")[2];
		String hstring = SettingsLoader.getdbStrings()[1].split("#")[2];
		String mstring = SettingsLoader.getdbStrings()[2].split("#")[2];
		String lstring = SettingsLoader.getdbStrings()[3].split("#")[2];

		//TODO simplify this mess pls... maybe interfaces?
		//Implementation had to be done with if's since case switch doesn't support variables
		if(tstring.equals(sensortype)) {
			TemperatureReading r = new TemperatureReading(dbo.get(SettingsLoader.getMongoIdField()).toString(),(Date)dbo.get(SettingsLoader.getMongoDateTimeField()),Double.valueOf(dbo.get(sensorfieldname).toString()));			
			ReadingLists.trList.add(r);		
			//Filters
			double newvalue = G23Utils.exponentiallyWeightedMovingAverage(SettingsLoader.getEwmaWeight()[0], SettingsLoader.getEwmaInitialValue()[0], r.getTemperature());
			TemperatureReading filteredreading = new TemperatureReading(r.getId(),r.getDatime(),newvalue);
			ReadingLists.filteredtrList.add(filteredreading);
		}
		if(hstring.equals(sensortype)) {
			HumidityReading r = new HumidityReading(dbo.get(SettingsLoader.getMongoIdField()).toString(), (Date)dbo.get(SettingsLoader.getMongoDateTimeField()),Double.valueOf(dbo.get(sensorfieldname).toString()));
			ReadingLists.hrList.add(r);
			//Filters
			double newvalue = G23Utils.exponentiallyWeightedMovingAverage(SettingsLoader.getEwmaWeight()[1], SettingsLoader.getEwmaInitialValue()[1], r.getHumidity());
			HumidityReading filteredreading = new HumidityReading(r.getId(),r.getDatime(),newvalue);
			ReadingLists.filteredhrList.add(filteredreading);
		}
		if(lstring.equals(sensortype)) {
			LuminosityReading r = new LuminosityReading(dbo.get(SettingsLoader.getMongoIdField()).toString(), (Date)dbo.get(SettingsLoader.getMongoDateTimeField()),Integer.valueOf(dbo.get(sensorfieldname).toString()));
			ReadingLists.lrList.add(r);
			//Filters
			//Does luminosity even make sense as an int???????????? Am I getting something wrong here?
			int newvalue = (int) Math.round(G23Utils.exponentiallyWeightedMovingAverage(SettingsLoader.getEwmaWeight()[3], SettingsLoader.getEwmaInitialValue()[3], r.getLuminosity()));
			LuminosityReading filteredreading = new LuminosityReading(r.getId(),r.getDatime(),newvalue);
			ReadingLists.filteredlrList.add(filteredreading);
		}
		if(mstring.equals(sensortype)) {
			MovementReading r = new MovementReading(dbo.get(SettingsLoader.getMongoIdField()).toString(), (Date)dbo.get(SettingsLoader.getMongoDateTimeField()),Integer.valueOf(dbo.get(sensorfieldname).toString()));
			ReadingLists.mrList.add(r);
			//Filters
			int newvalue = (int) Math.round(G23Utils.exponentiallyWeightedMovingAverage(SettingsLoader.getEwmaWeight()[2], SettingsLoader.getEwmaInitialValue()[2], r.getMovement()));
			MovementReading filteredreading = new MovementReading(r.getId(),r.getDatime(),newvalue);
			ReadingLists.filteredmrList.add(filteredreading);

		}








	}

}
