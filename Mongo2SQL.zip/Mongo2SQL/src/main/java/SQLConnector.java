import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.Collections;

import readings.HumidityReading;
import readings.LuminosityReading;
import readings.MovementReading;
import readings.TemperatureReading;
import utils.G23Utils;

public class SQLConnector {

	public String sqluser;
	public String sqlpassword;
	public String sqlconnectionpath;
	public Connection sqlconnection;


	public SQLConnector() {
		sqluser = SettingsLoader.getSqlUser();
		sqlpassword = SettingsLoader.getSqlPass();
		sqlconnectionpath = SettingsLoader.getSqlConnection();
		sqlconnection = null;

	}

	public void Connect() {

		try
		{ 	
			Class.forName("com.mysql.jdbc.Driver").newInstance();
			sqlconnection =  DriverManager.getConnection(sqlconnectionpath,sqluser,sqlpassword);
			System.out.println("Connected Sucessfully. ");
		}			
		catch (Exception e)
		{System.out.println("Server down, unable to connect. ");
		e.printStackTrace();
		}						

	}

	public void InsertReadings() { //TODO make the code better plsplsplspls
		//Reverse so when we add them to SQL the Highest ID is the most recent result
		Collections.reverse(ReadingLists.filteredtrList);
		Collections.reverse(ReadingLists.filteredhrList);
		Collections.reverse(ReadingLists.filteredmrList);
		Collections.reverse(ReadingLists.filteredlrList);
		//We now get latest result's timestamp so we assure we don't insert old values into the SQL DB
		Timestamp last_temperature_timestamp = getLastTMPTimestamp();
		Timestamp last_humidity_timestamp = getLastHUMTimestamp();
		Timestamp last_movement_timestamp = getLastMOVTimestamp();
		Timestamp last_luminosity_timestamp = getLastCELTimestamp();



		//TODO hardcode less
		for(TemperatureReading r : ReadingLists.filteredtrList) {
			Timestamp timestamp = G23Utils.getTimestamp(r.getDatime());

			if(timestamp.after(last_temperature_timestamp)) {
				System.out.println(timestamp.toString() + last_temperature_timestamp.toString());
				String sqlcommand = "Insert into Medicoes (TipoSensor, valor, datahora) values ("+ "'tmp', " + r.getTemperature() + ", " + "'"+timestamp+"'" + ");";
				System.out.println(sqlcommand); //debug
				insertintoSQLDB(sqlcommand);
			}
			else
				System.out.println("Tried to add a value to the DB but there are more recent ones");
		}
		for(HumidityReading r : ReadingLists.filteredhrList) {
			Timestamp timestamp = G23Utils.getTimestamp(r.getDatime());

			if(timestamp.after(last_humidity_timestamp)) {
				String sqlcommand = "Insert into Medicoes (TipoSensor, valor, datahora) values ("+ "'hum', " + r.getHumidity() + ", " + "'"+timestamp+"'" + ");";
				System.out.println(sqlcommand); //debug
				insertintoSQLDB(sqlcommand);
		

			}
			else
				System.out.println("Tried to add a value to the DB but there are more recent ones");

		}
		for(LuminosityReading r : ReadingLists.filteredlrList) {
			Timestamp timestamp = G23Utils.getTimestamp(r.getDatime());

			if(timestamp.after(last_temperature_timestamp)) {
				String sqlcommand = "Insert into Medicoes (TipoSensor, valor, datahora) values ("+ "'cel', " + r.getLuminosity() + ", " + "'"+timestamp+"'" + ");";
				System.out.println(sqlcommand); //debug
				insertintoSQLDB(sqlcommand);
			

			}
			else
				System.out.println("Tried to add a value to the DB but there are more recent ones");

		}
		for(MovementReading r : ReadingLists.filteredmrList) {
			Timestamp timestamp = G23Utils.getTimestamp(r.getDatime());

			if(timestamp.after(last_temperature_timestamp)) {
				String sqlcommand = "Insert into Medicoes (TipoSensor, valor, datahora) values ("+ "'mov', " + r.getMovement() + ", " + "'"+timestamp+"'" + ");";
				System.out.println(sqlcommand); //debug
				insertintoSQLDB(sqlcommand);
				

			}
			else
				System.out.println("Tried to add a value to the DB but there are more recent ones");

		}


		ReadingLists.clearLists();

	}

	private Timestamp getLastTMPTimestamp() {
		Timestamp lasttimestamp = null;
		String selectlastTMPcommand = "SELECT * FROM medicoes where TipoSensor = 'tmp' ORDER BY id DESC LIMIT 0, 1;";
		try {
			Statement statement = sqlconnection.createStatement();
			ResultSet rs = statement.executeQuery(selectlastTMPcommand);
			while (rs.next()){
				lasttimestamp = rs.getTimestamp("datahora");
			}
		}
		catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		return lasttimestamp;

	}

	private Timestamp getLastMOVTimestamp() {
		Timestamp lasttimestamp = null;
		String selectlastTMPcommand = "SELECT * FROM medicoes where TipoSensor = 'mov' ORDER BY id DESC LIMIT 0, 1;";
		try {
			Statement statement = sqlconnection.createStatement();
			ResultSet rs = statement.executeQuery(selectlastTMPcommand);
			while (rs.next()){
				lasttimestamp = rs.getTimestamp("datahora");
			}
		}
		catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		return lasttimestamp;

	}
	private Timestamp getLastHUMTimestamp() {
		Timestamp lasttimestamp = null;
		String selectlastTMPcommand = "SELECT * FROM medicoes where TipoSensor = 'hum' ORDER BY id DESC LIMIT 0, 1;";
		try {
			Statement statement = sqlconnection.createStatement();
			ResultSet rs = statement.executeQuery(selectlastTMPcommand);
			while (rs.next()){
				lasttimestamp = rs.getTimestamp("datahora");
			}
		}
		catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		return lasttimestamp;

	}
	private Timestamp getLastCELTimestamp() {
		Timestamp lasttimestamp = null;
		String selectlastTMPcommand = "SELECT * FROM medicoes where TipoSensor = 'cel' ORDER BY id DESC LIMIT 0, 1;";
		try {
			Statement statement = sqlconnection.createStatement();
			ResultSet rs = statement.executeQuery(selectlastTMPcommand);
			while (rs.next()){
				lasttimestamp = rs.getTimestamp("datahora");
			}
		}
		catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		return lasttimestamp;

	}

	private void insertintoSQLDB(String sqlcommand) {
		try { //Try to put it in the MySQL DB
			Statement s = sqlconnection.createStatement();
			int result =  s.executeUpdate(sqlcommand);
			System.out.println(result); //debug
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}


	}
}

