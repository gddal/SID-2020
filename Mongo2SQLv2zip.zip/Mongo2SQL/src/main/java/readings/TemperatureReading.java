package readings;

import java.util.Date;

public class TemperatureReading extends Reading {
	

	private double temperature;

	
	public TemperatureReading(String id, Date datime, double temperature) {
		super(id,datime);
		this.temperature=temperature;

		
	}
	


	@Override
	public String toString() {
		return "TemperatureReading [temperature=" + temperature + " " + super.toString() + "]";
	}


	public double getTemperature() {
		return temperature;
	}

	
	
	
}
