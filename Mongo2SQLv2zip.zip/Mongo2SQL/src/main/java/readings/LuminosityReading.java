package readings;

import java.util.Date;

public class LuminosityReading extends Reading {
	

	private int Luminosity;

	
	public LuminosityReading(String id, Date datime, int Luminosity) {
		super(id,datime);
		this.Luminosity=Luminosity;

		
	}


	public int getLuminosity() {
		return Luminosity;
	}

	
	
	
}
