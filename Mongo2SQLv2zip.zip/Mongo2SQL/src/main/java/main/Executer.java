package main;

public class Executer {




	public static void main(String[] args) {
		SettingsLoader sl = new SettingsLoader();
		
		if(args.length>0)
			SettingsLoader.debug = Integer.parseInt(args[0]);
		
		if(args.length>1)
			SettingsLoader.path = args[1];

		MongoDBConnector mdbc = new MongoDBConnector(SettingsLoader.getmongoURI(), SettingsLoader.getdbName());
		mdbc.mongotoArrayList();
		
		if (SettingsLoader.debug > 1) {
			System.out.println(ReadingLists.filteredtrList);
			System.out.println(ReadingLists.trList);
		}
		
		
		SQLConnector sqlc = new SQLConnector();
		sqlc.Connect();
		sqlc.InsertReadings();

	}



}
