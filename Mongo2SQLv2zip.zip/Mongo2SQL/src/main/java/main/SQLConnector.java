package main;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.Collections;

import readings.HumidityReading;
import readings.LuminosityReading;
import readings.MovementReading;
import readings.TemperatureReading;
import utils.G23Utils;

public class SQLConnector {

	public String sqluser;
	public String sqlpassword;
	public String sqlconnectionpath;
	public Connection sqlconnection;


	public SQLConnector() {
		sqluser = SettingsLoader.getSqlUser();
		sqlpassword = SettingsLoader.getSqlPass();
		sqlconnectionpath = SettingsLoader.getSqlConnection();
		sqlconnection = null;

	}

	public void Connect() {

		try
		{ 	
			Class.forName("com.mysql.jdbc.Driver").newInstance();
			sqlconnection =  DriverManager.getConnection(sqlconnectionpath,sqluser,sqlpassword);
			if(SettingsLoader.debug>0)
				System.out.println("Connected Sucessfully to the SQL server");
		}			
		catch (Exception e)
		{
			if(SettingsLoader.debug>0)
				System.out.println("Server down, unable to connect. ");
			e.printStackTrace();
		}						

	}

	public void InsertReadings() { //TODO make the code better plsplsplspls
		if(SettingsLoader.debug>0)
			System.out.println("Inserting into mySQL DB...");
		//Reverse so when we add them to SQL the Highest ID is the most recent result
		Collections.reverse(ReadingLists.filteredtrList);
		Collections.reverse(ReadingLists.filteredhrList);
		Collections.reverse(ReadingLists.filteredmrList);
		Collections.reverse(ReadingLists.filteredlrList);
		//We now get latest result's timestamp so we assure we don't insert old values into the SQL DB
		Timestamp last_temperature_timestamp = getLastTMPTimestamp();
		Timestamp last_humidity_timestamp = getLastHUMTimestamp();
		Timestamp last_movement_timestamp = getLastMOVTimestamp();
		Timestamp last_luminosity_timestamp = getLastCELTimestamp();

		String insertMidText = SettingsLoader.getMedicoestablename() + " ("+SettingsLoader.getTiposensorname()+" , " + SettingsLoader.getValorname()+ " , " + SettingsLoader.getDatahoraname();


		//TODO hardcode less
		for(TemperatureReading r : ReadingLists.filteredtrList) {
			Timestamp timestamp = G23Utils.getTimestamp(r.getDatime());

			if(last_temperature_timestamp == null) {
				String sqlcommand = "Insert into "+ insertMidText +") values ("+ "'tmp', " + r.getTemperature() + ", " + "'"+timestamp+"'" + ");";
				insertintoSQLDB(sqlcommand);
			}
			else
				if(timestamp.after(last_temperature_timestamp)) {
					String sqlcommand = "Insert into "+ insertMidText +") values ("+ "'tmp', " + r.getTemperature() + ", " + "'"+timestamp+"'" + ");";
					insertintoSQLDB(sqlcommand);
				}

		}
		for(HumidityReading r : ReadingLists.filteredhrList) {
			Timestamp timestamp = G23Utils.getTimestamp(r.getDatime());

			if(last_humidity_timestamp == null) {
				String sqlcommand = "Insert into "+ insertMidText +") values ("+ "'hum', " + r.getHumidity() + ", " + "'"+timestamp+"'" + ");";
				insertintoSQLDB(sqlcommand);

			}
			else
				if(timestamp.after(last_humidity_timestamp)) {
					String sqlcommand = "Insert into "+ insertMidText +") values ("+ "'hum', " + r.getHumidity() + ", " + "'"+timestamp+"'" + ");";
					insertintoSQLDB(sqlcommand);


				}

		}
		for(LuminosityReading r : ReadingLists.filteredlrList) {
			Timestamp timestamp = G23Utils.getTimestamp(r.getDatime());

			if(last_luminosity_timestamp == null) {
				String sqlcommand = "Insert into "+ insertMidText +" ) values ("+ "'cel', " + r.getLuminosity() + ", " + "'"+timestamp+"'" + ");";
				insertintoSQLDB(sqlcommand);
			}
			else
				if(timestamp.after(last_luminosity_timestamp)) {
					String sqlcommand = "Insert into "+ insertMidText +" ) values ("+ "'cel', " + r.getLuminosity() + ", " + "'"+timestamp+"'" + ");";
					insertintoSQLDB(sqlcommand);


				}

		}
		for(MovementReading r : ReadingLists.filteredmrList) {
			Timestamp timestamp = G23Utils.getTimestamp(r.getDatime());

			if(last_movement_timestamp == null) {
				String sqlcommand = "Insert into " + insertMidText +") values ("+ "'mov', " + r.getMovement() + ", " + "'"+timestamp+"'" + ");";
				insertintoSQLDB(sqlcommand);
			}
			else
				if(timestamp.after(last_movement_timestamp)) {
					String sqlcommand = "Insert into " + insertMidText +") values ("+ "'mov', " + r.getMovement() + ", " + "'"+timestamp+"'" + ");";
					insertintoSQLDB(sqlcommand);


				}





		}

		if(SettingsLoader.debug>0)
			System.out.println("Finished Inserting in mySQL DB");
		ReadingLists.clearLists();

	}

	private Timestamp getLastTMPTimestamp() {
		Timestamp lasttimestamp = null;
		String selectlastTMPcommand = "SELECT * FROM " + SettingsLoader.getMedicoestablename()+ " where " + SettingsLoader.getTiposensorname() + " = 'tmp' ORDER BY id DESC LIMIT 0, 1;";
		try {
			Statement statement = sqlconnection.createStatement();
			ResultSet rs = statement.executeQuery(selectlastTMPcommand);
			while (rs.next()){
				lasttimestamp = rs.getTimestamp(SettingsLoader.getDatahoraname());
			}
		}
		catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		return lasttimestamp;

	}

	private Timestamp getLastMOVTimestamp() {
		Timestamp lasttimestamp = null;
		String selectlastTMPcommand = "SELECT * FROM " + SettingsLoader.getMedicoestablename()+ " where " + SettingsLoader.getTiposensorname() + " = 'mov' ORDER BY id DESC LIMIT 0, 1;";
		try {
			Statement statement = sqlconnection.createStatement();
			ResultSet rs = statement.executeQuery(selectlastTMPcommand);
			while (rs.next()){
				lasttimestamp = rs.getTimestamp("datahora");
			}
		}
		catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		return lasttimestamp;

	}
	private Timestamp getLastHUMTimestamp() {
		Timestamp lasttimestamp = null;
		String selectlastTMPcommand = "SELECT * FROM " + SettingsLoader.getMedicoestablename()+ " where " + SettingsLoader.getTiposensorname() + " = 'hum' ORDER BY id DESC LIMIT 0, 1;";
		try {
			Statement statement = sqlconnection.createStatement();
			ResultSet rs = statement.executeQuery(selectlastTMPcommand);
			while (rs.next()){
				lasttimestamp = rs.getTimestamp("datahora");
			}
		}
		catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		return lasttimestamp;

	}
	private Timestamp getLastCELTimestamp() {
		Timestamp lasttimestamp = null;
		String selectlastTMPcommand = "SELECT * FROM " + SettingsLoader.getMedicoestablename()+ " where " + SettingsLoader.getTiposensorname() + " = 'cel' ORDER BY id DESC LIMIT 0, 1;";
		try {
			Statement statement = sqlconnection.createStatement();
			ResultSet rs = statement.executeQuery(selectlastTMPcommand);
			while (rs.next()){
				lasttimestamp = rs.getTimestamp("datahora");
			}
		}
		catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		return lasttimestamp;

	}

	private void insertintoSQLDB(String sqlcommand) {
		try { //Try to put it in the MySQL DB
			if(SettingsLoader.debug >0)
				System.out.println(sqlcommand);
			Statement s = sqlconnection.createStatement();
			int result =  s.executeUpdate(sqlcommand);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}


	}
}

